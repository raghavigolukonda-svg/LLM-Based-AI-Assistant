import React from 'react';
import { motion } from 'motion/react';
import { LogIn, Sparkles, Shield, Cpu, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { signInWithGoogle } from '../lib/firebase';

export function Auth() {
  return (
    <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] bg-primary/5 rounded-full blur-[100px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-[#18181B] border border-[#27272A] rounded-3xl p-8 shadow-2xl relative z-10"
      >
        <div className="flex flex-col items-center text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(59,130,246,0.3)]">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-white mb-2">Nexus Architect</h1>
          <p className="text-muted-foreground text-sm max-w-[280px]">
            The next generation architectural AI system for high-performance reasoning.
          </p>
        </div>

        <div className="space-y-4 mb-10">
          {[
            { icon: Cpu, text: "Gemini 3.1 Pro Engine" },
            { icon: Shield, text: "Advanced Guardrails" },
            { icon: Zap, text: "Low Latency Processing" }
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 p-3 bg-[#0F0F12] border border-[#27272A] rounded-xl text-xs text-muted-foreground">
              <item.icon className="w-4 h-4 text-primary" />
              {item.text}
            </div>
          ))}
        </div>

        <Button 
          className="w-full h-12 bg-white hover:bg-white/90 text-black font-bold rounded-xl flex items-center justify-center gap-3 transition-all"
          onClick={signInWithGoogle}
        >
          <LogIn className="w-5 h-5" />
          Sign Tech-In with Google
        </Button>

        <p className="mt-8 text-center text-[10px] text-muted-foreground uppercase tracking-widest leading-relaxed">
          Authorized access only<br />
          System Protocol v4.2.0
        </p>
      </motion.div>
    </div>
  );
}
