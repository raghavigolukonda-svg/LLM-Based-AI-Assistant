import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Send, 
  Paperclip, 
  Trash2, 
  MessageSquare, 
  User, 
  Bot, 
  FileText, 
  MoreVertical,
  Settings,
  Shield,
  History,
  Menu,
  X,
  FileIcon,
  ChevronDown,
  Sparkles,
  Command,
  Activity,
  Zap,
  Lock,
  Cpu,
  Globe,
  Search,
  LogOut,
  Eye,
  EyeOff
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Textarea } from '@/components/ui/textarea';

import { Message, ChatSession, AttachedFile } from './types';
import { streamChat } from './lib/gemini';
import { extractTextFromPdf, fileToBase64 } from './lib/pdf';
import ReactMarkdown from 'react-markdown';

import { auth, signInWithGoogle } from './lib/firebase';
import { FirebaseService } from './lib/firebaseService';
import { onAuthStateChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { Auth } from './components/Auth';

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isCreatingSession = useRef(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthLoading(false);
      if (u) {
        FirebaseService.syncUserProfile(u);
      }
    });
    return () => unsubscribe();
  }, []);

  // Sessions Listener
  useEffect(() => {
    if (!user) return;
    const unsubscribe = FirebaseService.subscribeToSessions(user.uid, (fetchedSessions) => {
      setSessions(fetchedSessions);
      
      // Auto-select first session if none exists locally
      if (fetchedSessions.length > 0 && !currentSessionId) {
        setCurrentSessionId(fetchedSessions[0].id);
      } 
      
      // Real-time Sync: If current session was deleted on another device, re-select
      if (currentSessionId && !fetchedSessions.some(s => s.id === currentSessionId)) {
        setCurrentSessionId(fetchedSessions.length > 0 ? fetchedSessions[0].id : null);
      }

      // If absolutely no sessions, auto-create one (with lock)
      if (fetchedSessions.length === 0 && !isCreatingSession.current) {
        createNewSession();
      }
    });
    return () => unsubscribe();
  }, [user, currentSessionId]);

  // Messages Listener for current session
  useEffect(() => {
    if (!currentSessionId || !user) return;
    const unsubscribe = FirebaseService.subscribeToMessages(currentSessionId, (messages) => {
      setSessions(prev => prev.map(s => 
        s.id === currentSessionId ? { ...s, messages } : s
      ));
    });
    return () => unsubscribe();
  }, [currentSessionId, user]);

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [sessions, currentSessionId, isStreaming]);

  const currentSession = sessions.find(s => s.id === currentSessionId);

  const filteredSessions = sessions.filter(s => 
    s.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const createNewSession = async () => {
    if (!user || isCreatingSession.current) return;
    isCreatingSession.current = true;
    try {
      const id = await FirebaseService.createSession(user.uid);
      setCurrentSessionId(id);
    } finally {
      isCreatingSession.current = false;
    }
  };

  const deleteSession = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    await FirebaseService.deleteSession(id);
    // currentSessionId update is handled by the useEffect listener now
  };

  const handleRename = async (id: string) => {
    if (!editTitle.trim()) {
      setEditingSessionId(null);
      return;
    }
    await FirebaseService.updateSession(id, { title: editTitle.trim() });
    setEditingSessionId(null);
    setEditTitle('');
  };

  const handleFileUpload = async (files: FileList | null) => {
    if (!files) return;

    for (const file of Array.from(files)) {
      let content = '';
      try {
        if (file.type === 'application/pdf') {
          content = await extractTextFromPdf(file);
        } else if (file.type.startsWith('image/')) {
          content = await fileToBase64(file);
        } else {
          content = await file.text();
        }

        setAttachedFiles(prev => [...prev, {
          name: file.name,
          type: file.type,
          content,
          size: file.size
        }]);
      } catch (err) {
        console.error('File parsing error:', err);
      }
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileUpload(e.dataTransfer.files);
  };

  const handleSendMessage = async () => {
    if ((!input.trim() && attachedFiles.length === 0) || isStreaming || !currentSessionId || !user) return;

    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
      files: attachedFiles.length > 0 ? [...attachedFiles] : undefined
    };

    // Update firestore
    await FirebaseService.addMessage(currentSessionId, userMessage);

    // Update title if first message
    if (currentSession && (currentSession.messages?.length || 0) === 0) {
      await FirebaseService.updateSession(currentSessionId, { title: input.slice(0, 30) || 'File Analysis' });
    }

    setInput('');
    setAttachedFiles([]);
    setIsStreaming(true);

    const assistantMessageId = crypto.randomUUID();
    const initialAssistantMessage: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: Date.now()
    };

    await FirebaseService.addMessage(currentSessionId, initialAssistantMessage);

    try {
      const sessionWithLatest = sessions.find(s => s.id === currentSessionId);
      const chatStream = streamChat([...(sessionWithLatest?.messages || []), userMessage]);
      
      let fullContent = '';
      let lastUpdateTime = 0;
      const THROTTLE_MS = 300; // Throttle firestore writes during streaming

      for await (const chunk of chatStream) {
        fullContent += (chunk || '');
        const now = Date.now();
        if (now - lastUpdateTime > THROTTLE_MS) {
          await FirebaseService.updateMessage(currentSessionId, assistantMessageId, fullContent);
          lastUpdateTime = now;
        }
      }
      // Final definitive update
      await FirebaseService.updateMessage(currentSessionId, assistantMessageId, fullContent);
    } catch (error) {
      console.error('Streaming error:', error);
      await FirebaseService.updateMessage(currentSessionId, assistantMessageId, 'Sorry, I encountered an error. Please try again.');
    } finally {
      setIsStreaming(false);
    }
  };

  const getSessionGroups = () => {
    const groups: { [key: string]: ChatSession[] } = {
      'Today': [],
      'Yesterday': [],
      'Previous 7 Days': [],
      'Older': []
    };

    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const yesterdayStart = todayStart - 86400000;
    const sevenDaysStart = todayStart - 86400000 * 7;

    filteredSessions.forEach(session => {
      const date = session.updatedAt || Date.now();
      if (date >= todayStart) groups['Today'].push(session);
      else if (date >= yesterdayStart) groups['Yesterday'].push(session);
      else if (date >= sevenDaysStart) groups['Previous 7 Days'].push(session);
      else groups['Older'].push(session);
    });

    return groups;
  };

  if (authLoading) {
    return (
      <div className="h-screen bg-[#0A0A0B] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Auth />;
  }

  return (
    <TooltipProvider>
      <div 
        className="flex h-screen bg-[#0A0A0B] text-foreground font-sans overflow-hidden relative"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <AnimatePresence>
          {isDragging && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 bg-primary/10 backdrop-blur-sm border-4 border-dashed border-primary flex items-center justify-center m-4 rounded-3xl"
            >
              <div className="flex flex-col items-center gap-4 text-primary">
                <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center animate-bounce">
                  <Plus className="w-10 h-10" />
                </div>
                <p className="text-2xl font-bold">Drop files to Architect AI</p>
                <p className="text-sm opacity-60">PDF, Images, or Text files are supported</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sidebar */}
        <motion.aside 
          initial={false}
          animate={{ width: isSidebarOpen ? 280 : 0, opacity: isSidebarOpen ? 1 : 0 }}
          className="bg-[#0F0F12] border-r border-[#1F1F23] flex flex-col relative z-20 overflow-hidden"
        >
          <div className="p-6 flex flex-col min-w-[280px] h-full">
            <div className="flex items-center justify-between mb-8 px-2">
              <div className="flex items-center gap-2 font-bold text-[12px] uppercase tracking-[2px] text-primary">
                <div className="w-2.5 h-2.5 rounded-full bg-primary shadow-[0_0_10px_#3B82F6]" />
                Architect AI
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 text-muted-foreground/40 hover:text-white"
                onClick={() => setIsSidebarOpen(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            <Button 
              className="w-full bg-[#18181B] hover:bg-[#27272A] text-white border border-[#27272A] rounded-xl h-10 flex items-center justify-start gap-3 px-4 mb-6 transition-all group"
              onClick={() => createNewSession()}
            >
              <Plus className="w-4 h-4 text-primary group-hover:scale-110 transition-transform" />
              <span className="text-sm font-medium">New Conversation</span>
              <Command className="w-3 h-3 ml-auto opacity-30" />
            </Button>

            <div className="relative mb-6 px-2">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground/30" />
              <input 
                type="text"
                placeholder="Search history..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0A0A0B] border border-[#1F1F23] rounded-lg py-1.5 pl-9 pr-3 text-[12px] text-zinc-400 outline-none focus:border-primary/50 transition-all font-light"
              />
            </div>

            <ScrollArea className="flex-1 -mx-2 px-2">
              <div className="space-y-6 pb-4">
                {Object.entries(getSessionGroups()).map(([groupName, groupSessions]) => (
                  groupSessions.length > 0 && (
                    <div key={groupName} className="space-y-1">
                      <div className="px-2 mb-2">
                        <span className="text-[10px] font-bold text-muted-foreground/30 uppercase tracking-[2px]">{groupName}</span>
                      </div>
                      {groupSessions.map(session => (
                        <div
                          key={session.id}
                          onClick={() => setCurrentSessionId(session.id)}
                          className={`
                            group flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-all duration-200
                            ${currentSessionId === session.id 
                              ? 'bg-[#18181B] text-primary shadow-sm border border-primary/10' 
                              : 'hover:bg-muted/10 text-muted-foreground/60 hover:text-zinc-300'}
                          `}
                        >
                          <MessageSquare className={`w-4 h-4 shrink-0 ${currentSessionId === session.id ? 'text-primary' : 'opacity-40'}`} />
                          
                          {editingSessionId === session.id ? (
                            <input 
                              autoFocus
                              className="bg-transparent border-none outline-none text-[13px] flex-1 text-white"
                              value={editTitle}
                              onChange={(e) => setEditTitle(e.target.value)}
                              onBlur={() => handleRename(session.id)}
                              onKeyDown={(e) => e.key === 'Enter' && handleRename(session.id)}
                              onClick={(e) => e.stopPropagation()}
                            />
                          ) : (
                            <span className="flex-1 truncate text-[13px]">
                              {session.title}
                            </span>
                          )}

                          <DropdownMenu>
                            <DropdownMenuTrigger render={
                              <button className="h-6 w-6 opacity-0 group-hover:opacity-100 -mr-1 flex items-center justify-center rounded-md hover:bg-muted/20 transition-all" onClick={(e) => e.stopPropagation()}>
                                <MoreVertical className="w-3 h-3" />
                              </button>
                            } />
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={(e) => {
                                e.stopPropagation();
                                setEditingSessionId(session.id);
                                setEditTitle(session.title);
                              }}>
                                <FileText className="w-3.5 h-3.5 mr-2" />
                                Rename
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive" onClick={(e) => deleteSession(e, session.id)}>
                                <Trash2 className="w-3.5 h-3.5 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      ))}
                    </div>
                  )
                ))}
              </div>
            </ScrollArea>

            {/* Profile Portal */}
            <div className="pt-4 border-t border-[#1F1F23] mt-auto">
              <DropdownMenu>
                <DropdownMenuTrigger render={
                  <button className="w-full flex items-center gap-3 p-2 rounded-xl transition-colors hover:bg-muted/10 cursor-pointer group text-left border-none bg-transparent outline-none">
                    <Avatar className="w-9 h-9 border border-[#27272A] group-hover:border-primary/50 transition-colors">
                      <AvatarImage src={user?.photoURL || undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary text-xs">
                        {user?.displayName?.[0] || user?.email?.[0] || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 overflow-hidden">
                      <p className="text-[13px] font-semibold text-zinc-200 truncate">{user?.displayName || user?.email}</p>
                      <p className="text-[10px] text-muted-foreground/50 uppercase tracking-tight">Prime Citizen</p>
                    </div>
                    <ChevronDown className="w-4 h-4 text-muted-foreground/30 group-hover:text-primary transition-colors" />
                  </button>
                } />
                <DropdownMenuContent className="w-56" align="end" side="top" sideOffset={12}>
                  <DropdownMenuItem onClick={() => signOut(auth)}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Secure Terminate (Log Out)
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </motion.aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col overflow-hidden relative min-w-0 bg-[#0A0A0B]">
          {/* Header */}
          <header className="h-14 border-b border-[#1F1F23] flex items-center justify-between px-6 shrink-0 bg-[#0A0A0B]/80 backdrop-blur-xl z-20">
            <div className="flex items-center gap-4">
              {!isSidebarOpen && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8 text-muted-foreground hover:text-white"
                  onClick={() => setIsSidebarOpen(true)}
                >
                  <Menu className="w-5 h-5" />
                </Button>
              )}
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="font-mono text-[10px] tracking-[2px] bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
                  SYSTEM READY
                </Badge>
                <span className="text-xs text-muted-foreground/40 truncate max-w-[200px] hidden sm:inline font-mono">
                  SESSION: {currentSessionId?.slice(0, 8)}
                </span>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/5 text-emerald-500 rounded-full border border-emerald-500/20 text-[10px] font-bold">
                <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
                ENCRYPTED
              </div>
              <Separator orientation="vertical" className="h-6 bg-[#1F1F23]" />
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-white h-8 w-8">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </header>

          <div className="flex-1 min-h-0 flex flex-col relative">
            <ScrollArea className="flex-1">
              <div className="max-w-3xl mx-auto p-6 space-y-8">
                {currentSession?.messages?.length === 0 && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col items-center justify-center min-h-[60vh] text-center"
                  >
                    <div className="w-20 h-20 rounded-3xl bg-primary/10 mb-8 flex items-center justify-center text-primary shadow-[0_0_50px_rgba(59,130,246,0.1)]">
                      <Sparkles className="w-10 h-10 animate-flicker" />
                    </div>
                    <h1 className="text-4xl font-bold tracking-tight mb-4 text-white">Architectural Reasoning Engine</h1>
                    <p className="text-muted-foreground text-sm max-w-sm mx-auto mb-10 leading-relaxed uppercase tracking-wider font-medium opacity-40">
                      High-context data synthesis and autonomous problem solving standby.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg w-full">
                      {[
                        { icon: FileText, text: "Synthesize findings from my PDF repository" },
                        { icon: Command, text: "Generate high-optimization algorithm" },
                        { icon: Shield, text: "Perform security audit on codebase" },
                        { icon: MessageSquare, text: "Initiate strategic project planning" }
                      ].map((item, idx) => (
                        <Button 
                          key={idx} 
                          variant="outline" 
                          className="bg-[#0F0F12] border-[#27272A] hover:bg-[#18181B] hover:text-white justify-start h-auto py-5 px-6 text-left rounded-2xl group transition-all"
                          onClick={() => setInput(item.text)}
                        >
                          <item.icon className="w-4 h-4 mr-4 shrink-0 text-primary group-hover:scale-110 transition-transform" />
                          <span className="truncate text-[13px]">{item.text}</span>
                        </Button>
                      ))}
                    </div>
                  </motion.div>
                )}

                {currentSession?.messages?.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={`flex flex-col ${message.role === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div className={`max-w-[90%] flex flex-col gap-3 ${message.role === 'user' ? 'items-end' : 'items-start'}`}>
                      {message.role === 'assistant' && (
                        <div className="text-[10px] font-bold text-primary uppercase tracking-[3px] flex items-center gap-2 mb-1 px-1">
                          <Bot className="w-3.5 h-3.5" />
                          ARCHITECT SEQUENCE
                        </div>
                      )}
                      
                      {message.files && message.files.length > 0 && (
                        <div className="flex flex-wrap gap-2 mb-1">
                          {message.files.map((file, i) => (
                            <div key={i} className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#18181B] text-primary text-[11px] border border-primary/20">
                              <FileIcon className="w-3.5 h-3.5" />
                              <span className="truncate max-w-[150px]">{file.name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <div className={`
                        px-6 py-5 text-[14px] leading-[1.7]
                        ${message.role === 'user' 
                          ? 'bg-[#18181B] text-white rounded-3xl rounded-br-sm border border-[#27272A] shadow-xl' 
                          : 'bg-[#0F0F12] text-[#E4E4E7] border border-[#1F1F23] rounded-3xl rounded-bl-sm shadow-sm font-light'}
                      `}>
                        <div className="markdown-body prose prose-invert prose-sm max-w-none break-words tracking-wide">
                          <ReactMarkdown>{message.content}</ReactMarkdown>
                        </div>
                        {message.role === 'assistant' && message.content === '' && isStreaming && (
                          <div className="flex gap-1.5 py-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce shadow-[0_0_8px_#3B82F6]" />
                            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:0.2s] shadow-[0_0_8px_#3B82F6]" />
                            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:0.4s] shadow-[0_0_8px_#3B82F6]" />
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
                <div ref={messagesEndRef} className="h-12 shrink-0" />
              </div>
            </ScrollArea>
          </div>

          {/* Input Area */}
          <div className="p-8 shrink-0 border-t border-[#1F1F23] bg-[#0A0A0B]/50 backdrop-blur-xl">
            <div className="max-w-3xl mx-auto">
              <AnimatePresence>
                {showPreview && input.trim() && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, height: 0 }}
                    animate={{ opacity: 1, y: 0, height: 'auto' }}
                    exit={{ opacity: 0, y: 10, height: 0 }}
                    className="mb-4 overflow-hidden"
                  >
                    <div className="bg-[#0F0F12] border border-[#1F1F23] rounded-2xl p-6 shadow-2xl relative">
                      <div className="absolute top-3 right-4 text-[9px] font-black text-primary/40 uppercase tracking-[2px] flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3" />
                        Live Preview
                      </div>
                      <div className="markdown-body prose prose-invert prose-sm max-w-none opacity-80 min-h-[40px]">
                        <ReactMarkdown>{input}</ReactMarkdown>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="relative bg-[#0F0F12] border border-[#1F1F23] rounded-2xl shadow-[0_0_60px_-12px_rgba(0,0,0,0.7)] overflow-hidden focus-within:border-primary/40 focus-within:ring-4 ring-primary/5 transition-all duration-300">
                {attachedFiles.length > 0 && (
                  <div className="flex flex-wrap gap-2 px-5 py-4 border-b border-[#1F1F23] bg-primary/5">
                    <AnimatePresence>
                      {attachedFiles.map((file, idx) => (
                        <motion.div 
                          key={idx}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#18181B] text-primary text-[11px] border border-primary/20 group pr-1"
                        >
                          <FileIcon className="w-3.5 h-3.5" />
                          <span className="max-w-[120px] truncate">{file.name}</span>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-destructive/10 hover:text-destructive transition-all"
                            onClick={() => setAttachedFiles(prev => prev.filter((_, i) => i !== idx))}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
                
                <div className="flex items-center px-5 py-3 gap-2 min-h-[72px]">
                  <Tooltip>
                    <TooltipTrigger render={
                      <button 
                        className="h-10 w-10 text-muted-foreground/30 hover:text-primary transition-colors rounded-xl items-center justify-center flex hover:bg-muted/10"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <Plus className="w-5 h-5 translate-y-[1px]" />
                      </button>
                    } />
                    <TooltipContent>Attach Payload</TooltipContent>
                  </Tooltip>
                  
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    multiple
                    onChange={(e) => handleFileUpload(e.target.files)}
                  />
                  
                  <input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Enter command for Architect AI..."
                    className="flex-1 bg-transparent border-0 focus:ring-0 outline-none text-[16px] py-4 text-zinc-100 placeholder:text-muted-foreground/20 font-light"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                  />

                  <Tooltip>
                    <TooltipTrigger render={
                      <button 
                        className={`h-10 w-10 transition-all rounded-xl items-center justify-center flex ${showPreview ? 'text-primary bg-primary/10 shadow-[0_0_15px_rgba(59,130,246,0.2)]' : 'text-muted-foreground/30 hover:text-primary hover:bg-muted/10'}`}
                        onClick={() => setShowPreview(!showPreview)}
                      >
                        {showPreview ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    } />
                    <TooltipContent>{showPreview ? 'Hide Preview' : 'Show Markdown Preview'}</TooltipContent>
                  </Tooltip>
                  
                  <Button 
                    size="icon" 
                    disabled={(!input.trim() && attachedFiles.length === 0) || isStreaming}
                    onClick={handleSendMessage}
                    className={`h-11 w-11 rounded-xl transition-all duration-300 ${input.trim() || attachedFiles.length > 0 ? 'bg-primary text-white shadow-[0_0_20px_rgba(59,130,246,0.3)] hover:scale-105' : 'bg-[#18181B] text-muted-foreground/20'}`}
                  >
                    {isStreaming ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Send className="w-5 h-5 -rotate-12 translate-x-0.5" />
                    )}
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center gap-8 mt-6">
                {[
                  { label: "AUTH", val: "L3-VERIFIED", color: "text-emerald-500" },
                  { label: "DATA", val: "ENC-AES256", color: "text-primary" },
                  { label: "CORE", val: "OS-v4.2", color: "text-zinc-600" }
                ].map((stat, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="text-[9px] font-black text-muted-foreground/20 uppercase tracking-[2px]">{stat.label}</span>
                    <span className={`text-[9px] font-mono font-bold ${stat.color} tracking-tight`}>{stat.val}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>

        {/* Right Sidebar (Stats Panel) */}
        <aside className="hidden 2xl:flex w-[280px] bg-[#0F0F12] border-l border-[#1F1F23] flex-col p-8 gap-10 overflow-y-auto">
          <div className="space-y-6">
            <div className="text-[10px] font-black text-muted-foreground/30 uppercase tracking-[3px]">Hardware Telemetry</div>
            <Card className="bg-[#18181B] border-[#27272A] p-6 space-y-4 rounded-2xl shadow-xl border-l-4 border-l-primary">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Signal Health</span>
                <span className="font-mono text-xs font-bold text-primary">99.9%</span>
              </div>
              <div className="h-1 bg-[#0A0A0B] rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '99.9%' }}
                  className="h-full bg-primary shadow-[0_0_10px_#3B82F6]"
                />
              </div>
              <p className="text-[10px] text-muted-foreground/40 leading-relaxed italic">Encryption layers active. Packet loss minimal.</p>
            </Card>
            <Card className="bg-[#18181B] border-[#27272A] p-6 rounded-2xl">
              <div className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold mb-3">Model Throughput</div>
              <div className="font-mono text-2xl font-bold text-white flex items-center justify-between">
                8.4 T/S
                <Activity className="w-5 h-5 text-emerald-500 animate-pulse" />
              </div>
              <div className="mt-4 flex gap-1 h-8 items-end">
                {[40, 70, 45, 90, 65, 80, 50, 95].map((h, i) => (
                  <motion.div 
                    key={i} 
                    initial={{ height: 0 }}
                    animate={{ height: `${h}%` }}
                    className="flex-1 bg-primary/20 rounded-t-sm"
                  />
                ))}
              </div>
            </Card>
          </div>

          <div className="space-y-6">
            <div className="text-[10px] font-black text-muted-foreground/30 uppercase tracking-[3px]">Encryption Protocol</div>
            <div className="space-y-3">
              {[
                { icon: Shield, text: "Advanced Guard Bypass", color: "text-emerald-400" },
                { icon: Lock, text: "Zero-Knowledge Storage", color: "text-primary" }
              ].map((guard, i) => (
                <div key={i} className="flex items-center gap-4 p-4 bg-[#18181B]/40 border border-[#27272A] rounded-2xl text-[11px] text-zinc-400 group hover:border-primary/20 transition-all hover:translate-x-1">
                  <guard.icon className={`w-4 h-4 ${guard.color} group-hover:scale-110 transition-transform`} />
                  {guard.text}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6 mt-auto">
            <div className="text-[10px] font-black text-muted-foreground/30 uppercase tracking-[3px]">System Version</div>
            <div className="space-y-3">
              {[
                { label: "OS KERNEL", level: "v4.2.0-STABLE" },
                { label: "AI_NODE", level: "OPTIMAL" },
                { label: "AUTH_GATE", level: "VERIFIED" }
              ].map((h, i) => (
                <div key={i} className="flex justify-between items-center text-[10px]">
                  <span className="text-zinc-600 font-bold tracking-tight">{h.label}</span>
                  <span className="text-primary font-mono font-bold uppercase tracking-tighter">{h.level}</span>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </TooltipProvider>
  );
}
