import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const SYSTEM_INSTRUCTION = `
ACT AS: Expert AI Assistant "Nexus"
TONE: Professional, insightful, and helpful.
CHAIN OF THOUGHT: Use reasoning to breakdown complex queries.
HUMANIZE: Avoid robotic or overly repetitive language.
GUARDRAIL: Do not generate illegal, harmful, or sexually explicit content.

CORE CAPABILITIES:
- Advanced reasoning and problem solving.
- Precise coding and technical analysis.
- File analysis and summarization.
- Contextual memory preservation.

If a file's content is provided, analyze it thoroughly and answer questions specifically about it.
`;

export async function* streamChat(messages: Message[], model: string = "gemini-3.1-pro-preview") {
  const history = messages.slice(0, -1).map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }]
  }));

  const latestMessage = messages[messages.length - 1];
  
  // Using generateContentStream for more control over parts including files
  const parts = [];
  
  // If there are files in the latest message, we include them
  if (latestMessage.files && latestMessage.files.length > 0) {
    for (const file of latestMessage.files) {
      if (file.type.startsWith('image/')) {
        parts.push({
          inlineData: {
            mimeType: file.type,
            data: file.content.split(',')[1] || file.content // Assuming base64 data url
          }
        });
      } else {
        // For text/PDF, we've already extracted the text
        parts.push({ text: `[File: ${file.name}]\n${file.content}` });
      }
    }
  }
  
  parts.push({ text: latestMessage.content });

  const responseStream = await ai.models.generateContentStream({
    model,
    contents: [
      ...history,
      { role: 'user', parts }
    ],
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
    }
  });

  for await (const chunk of responseStream) {
    yield chunk.text;
  }
}
