import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  serverTimestamp,
  addDoc,
  Timestamp,
  getDocs
} from 'firebase/firestore';
import { db } from './firebase';
import { ChatSession, Message } from '../types';

const SESSIONS_COLLECTION = 'sessions';
const MESSAGES_COLLECTION = 'messages';

export const FirebaseService = {
  // Listen to sessions
  subscribeToSessions: (userId: string, callback: (sessions: ChatSession[]) => void) => {
    const q = query(
      collection(db, SESSIONS_COLLECTION),
      where('userId', '==', userId),
      orderBy('updatedAt', 'desc')
    );

    return onSnapshot(q, (snapshot) => {
      const sessions: any[] = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        updatedAt: (doc.data().updatedAt as Timestamp)?.toMillis() || Date.now(),
        createdAt: (doc.data().createdAt as Timestamp)?.toMillis() || Date.now(),
      }));
      callback(sessions);
    }, (error) => {
      console.error("Session subscription error:", error);
    });
  },

  // Listen to messages
  subscribeToMessages: (sessionId: string, callback: (messages: Message[]) => void) => {
    const q = query(
      collection(db, SESSIONS_COLLECTION, sessionId, MESSAGES_COLLECTION),
      orderBy('timestamp', 'asc')
    );

    return onSnapshot(q, (snapshot) => {
      const messages: any[] = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timestamp: (doc.data().timestamp as Timestamp)?.toMillis() || Date.now(),
      }));
      callback(messages);
    });
  },

  // Create session
  createSession: async (userId: string, title: string = 'New Conversation') => {
    const sessionRef = doc(collection(db, SESSIONS_COLLECTION));
    const sessionId = sessionRef.id;
    
    await setDoc(sessionRef, {
      id: sessionId,
      userId,
      title,
      updatedAt: serverTimestamp(),
      createdAt: serverTimestamp()
    });
    
    return sessionId;
  },

  // Update session
  updateSession: async (sessionId: string, data: Partial<ChatSession>) => {
    const sessionRef = doc(db, SESSIONS_COLLECTION, sessionId);
    // Always include updatedAt to satisfy security rules (updatedAt == request.time)
    const updateData: any = { 
      ...Object.fromEntries(Object.entries(data).filter(([_, v]) => v !== undefined)),
      updatedAt: serverTimestamp() 
    };
    await updateDoc(sessionRef, updateData);
  },

  // Delete session
  deleteSession: async (sessionId: string) => {
    // Delete messages first
    const messagesRef = collection(db, SESSIONS_COLLECTION, sessionId, MESSAGES_COLLECTION);
    const messagesSnap = await getDocs(messagesRef);
    for (const messageDoc of messagesSnap.docs) {
      await deleteDoc(messageDoc.ref);
    }
    await deleteDoc(doc(db, SESSIONS_COLLECTION, sessionId));
  },

  // Add message
  addMessage: async (sessionId: string, message: Message) => {
    const messagesRef = collection(db, SESSIONS_COLLECTION, sessionId, MESSAGES_COLLECTION);
    const messageDocRef = doc(messagesRef, message.id);
    
    // Stripe undefined fields (like files: undefined) which crash setDoc
    const cleanMessage = Object.fromEntries(
      Object.entries(message).filter(([_, v]) => v !== undefined)
    );

    await setDoc(messageDocRef, {
      ...cleanMessage,
      timestamp: serverTimestamp()
    });

    // Update parent session updatedAt for sorting and security compliance
    await updateDoc(doc(db, SESSIONS_COLLECTION, sessionId), {
      updatedAt: serverTimestamp()
    });
  },

  // Update existing message (for streaming)
  updateMessage: async (sessionId: string, messageId: string, content: string) => {
    const messageRef = doc(db, SESSIONS_COLLECTION, sessionId, MESSAGES_COLLECTION, messageId);
    await updateDoc(messageRef, {
      content
    });
  },

  // Sync user profile
  syncUserProfile: async (user: any) => {
    const userRef = doc(db, 'users', user.uid);
    // Use setDoc with a guard: don't overwrite createdAt if it exists
    // We send it originally, but rules will protect it from updates
    try {
      await setDoc(userRef, {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
        lastLogin: serverTimestamp(), // Track login instead of overwriting creation
        createdAt: serverTimestamp()
      }, { merge: true });
    } catch (err) {
      // If update fails because of createdAt immutability, try updating just the mutable fields
      await updateDoc(userRef, {
        displayName: user.displayName,
        photoURL: user.photoURL,
        lastLogin: serverTimestamp()
      });
    }
  }
};
