# Security Specification - Nexus AI

## Data Invariants
1. A ChatSession must have a `userId` matching the authenticated user.
2. A Message must belong to a ChatSession owned by the authenticated user.
3. Users can only read/write their own profiles.
4. Timestamps must be server-generated.

## The Dirty Dozen Payloads
1. Attempt to create a session for another user ID.
2. Attempt to read someone else's session.
3. Attempt to add a message to a session you don't own.
4. Attempt to update the `userId` of an existing session.
5. Attempt to create a message with a spoofed timestamp.
6. Attempt to upload a message with a massive `content` string (> 50KB).
7. Attempt to set `files` array to 1000 items.
8. Attempt to read the entire `users` collection.
9. Attempt to update another user's profile metadata.
10. Attempt to delete a session you don't own.
11. Attempt to create a session with an ID that is a 2KB string.
12. Attempt to bypass `email_verified` check if required (though only Google login is enabled, which usually verifies).

## The Test Runner
(This is a conceptual outline for `firestore.rules.test.ts`)
- `test('unauthenticated users cannot read sessions')`
- `test('authenticated users can only read their own sessions')`
- `test('users cannot create sessions for others')`
- `test('messages must match server timestamp')`
- ...
